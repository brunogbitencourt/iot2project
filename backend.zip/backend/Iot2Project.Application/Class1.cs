﻿namespace Iot2Project.Application;

public class Class1
{

}
