﻿namespace Iot2Project.Infrastructure;

public class Class1
{

}
