﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iot2Project.Domain.Entities
{
    internal class DeviceData
    {
    }
}
